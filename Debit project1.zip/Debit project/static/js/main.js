$(document).ready(function () {
    // console.log($('#add_data_tbody'))
    function isEmpty( el ){
        return !$.trim(el.html())
    }

    if(!is_last_row_empty() ||isEmpty($('#add_data_tbody'))){
        console.log("last row is empty")
        add_new_data();
    }
    function is_last_row_empty(){
        let result = true;
        $('#add_data_tbody tr:last').find('input').each(function(i, input) {
            if ($(input).val() != '') {
            result = false;
            }
        });
        return result;
    }

    function add_new_data(){
        $.post("/test",
        {
            action: "insert_empty"
        },
        function(id_item){
            str_html ="";
            str_html+='<tr id ='+id_item+'>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-sales_office"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Sales_area"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Order_Type"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Plant_code"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Sold_to_party"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Ship_to_party"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-PO_No"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-PO_Date"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Material"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Material_No"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Description"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Order_Quantity"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Unit_price"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Amount"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Reference_no"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Assignment"></td>';
            str_html+='    <td><input type="text" class ="new_input" id="'+id_item+'-Remark"></td>';
            str_html+='</tr>';
            $("#add_data_tbody").append(str_html);
        });
       
    }
    // function insert_empty_row(){

    // }
    function scrollToBottom (id) {
        var div = document.getElementById(id);
        div.scrollTop = div.scrollHeight - div.clientHeight;
        console.log(div.scrollTop)
     }

    // $("table.insert-table").on("focusout", "input", function (e) {
    //     if($(this).val()!=""){
    //         if ($(e.target).parents("tr").is("tr:last")) {
    //             // console.log("input event");
    //             // // $("#add_data_tbody").scrollTop($("#add_data_tbody").height());
    //             // scrollToBottom("add_data_tbody")
    //             add_new_data();
    //         }
    //     }
    // });
    function changeAlertStyle(selector,type, err_msg=""){
        if (type == "success"){
            $(".alert").css("display", "block");
            $(".alert").removeClass("alert-danger");
            $(".alert").addClass("alert-success");
            $(".alert").html("Update ok");
        }
        else if (type == "error"){
            $(".alert").css("display", "block");
            $(".alert").removeClass("alert-success");
            $(".alert").addClass("alert-danger");
            $(".alert").html(err_msg);
            $(selector).addClass("input_error");
            $(selector).val("");
            setTimeout(function(){ $(selector).removeClass("input_error"); }, 1000);
        }
    }

    function isInt(value) {
        return !isNaN(value) && 
               parseInt(Number(value)) == value && 
               !isNaN(parseInt(value, 10));
      }

    $(".btn_delete").click(function(){
        if (!confirm('Are you sure delete?')) {
            return;
          }

        id = $(this).attr("id");
        arr_id = id.split("-");
        debit_id = arr_id[1];
        $.post("/test",{
            action: "delete",
            id: debit_id
        },
        function(result){
            if(result == "ok"){
                $("#"+debit_id).remove();
                alert("Deleted!");
            }
            else{
                console.log("some thing error");
            }
        })
    });
    $(document).on("focusout","input",function(){
        // console.log($(this).attr('id'));
        var id_input = $(this).attr('id');
        var spl_txt = id_input.split("-");
        var id_item = spl_txt[0];
        var field_name = spl_txt[1];
        var value = $(this).val();
        
        if(field_name == "Order_Quantity"){
            if(!isInt(value)){
                console.log("Order Quantity field must be Integer!");
                changeAlertStyle(this,"error","Order Quantity field must be Integer!");
                return;
            }
        }
        else if(field_name == "Unit_price"){
            if(value.includes(".")){
                var arr_val = value.split(".");
                if(arr_val[1].length>5){
                    console.log("Unit Price field only 5 digit after . ");
                    changeAlertStyle(this,"error","Unit Price field only 5 digit after .");
                    return;
                }
            }
        }
        else if(field_name == "Amount"){
            if(value.includes(".")){
                var arr_val = value.split(".");
                if(arr_val[1].length>2){
                    console.log("Amount field field only 2 digit after .");
                    changeAlertStyle(this,"error","Amount field field only 2 digit after .");
                    return;
                }
            }
        }
        else if(field_name == "Reference_no"){
            if(value.length>100){
                changeAlertStyle(this,"error","Max length of Reference no is 100 character");
                return;
            }
        }
        if($(this).val()!=""){
            $.post("/test",
            {
                action: "update",
                id: id_item,
                field_name: field_name,
                value: value
            },
            function(result){
                console.log(id_input);
                if(result == "update ok"){
                    console.log(field_name);
                    console.log("#"+id_input+"-Description");
                    changeAlertStyle("#"+id_input,"success");
                    if (field_name == "Material"){
                        if ($("#"+id_item+"-Description").val()==""){
                            $("#"+id_item+"-Description").val(value);
                        }
                    }
                    // $("#"+id_input).removeClass("input_error");
                }
                else if(result == "nothing"){
                    return;
                }
                else{
                    changeAlertStyle("#"+id_input,"error", result);
                    return false;
                }
                if(!is_last_row_empty()){
                    add_new_data();
                }
                // console.log(result)
            });
        }
    });
});