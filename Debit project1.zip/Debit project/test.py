from datetime import datetime
try:
    dt = datetime.strptime("1/1/2000", '%Y-%m-%d')
    print(dt)
except:
    dt = datetime.strptime("2000/1/1", '%Y/%m/%d')
    print(dt)

from models import Debit
def find_type(class_, colname):
    if hasattr(class_, '__table__') and colname in class_.__table__.c:
        return class_.__table__.c[colname].type
    for base in class_.__bases__:
        return find_type(base, colname)
    raise NameError(colname)

print (find_type(Debit, 'Unit_price'))
