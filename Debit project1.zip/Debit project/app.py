from flask import Flask, render_template, request, session, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from controllerMain import get_user_info, gen_table_html,get_list_debit,insert_empty_row, update_data,gen_table_html_not_input, delete_debit
from __init__ import app

app.secret_key = '12345'
@app.route("/", methods=['GET'])
def index():
    return render_template("index.html")

# @app.route("/update", methods=['POST'])
# def update():
#     if(request.method=="POST"):
#         id_item = str(request.form["id"])
#         field_name = str(request.form["field_name"])
#         value = str(request.form["value"])
#         # try:
#         result = update_data(id=id_item, field_name = field_name, value=value)
#         return result
#         #     return "1"
#         # except: return "0"

@app.route("/preview", methods= ['GET'])
def preview():
    if session.get('uid')==None:
        return redirect(url_for("test"))
    creator_id = session.get("uid")
    list_debit = get_list_debit(creator_id)
    html_table = gen_table_html_not_input(list_debit)
    return render_template("preview.html", html_table=html_table)


@app.route("/test", methods=['GET','POST'])
def insert_empty():
    session["uid"] = "V1036303"
    if(request.method=="POST"):
        if str(request.form["action"])=="delete":
            id_item = str(request.form["id"])
            if delete_debit(id_item):
                return "ok"
            else: return "not ok"
        if str(request.form["action"])=="update": 
            id_item = str(request.form["id"])

            field_name = str(request.form["field_name"])
            value = str(request.form["value"])
            result = update_data(id=id_item, field_name = field_name, value=value)
            return result
        # if str(request.form["action"])=="update": 
        #     id_item = str(request.form["id"])
        #     field_name = str(request.form["field_name"])
        #     value = str(request.form["value"])
        #     update_data(id=id_item, field_name = field_name, value=value)
        if str(request.form["action"])=="insert_empty": 
            return str(insert_empty_row(str(session["uid"])))

    user = get_user_info(str(session["uid"]))
    list_debit = get_list_debit(str(session["uid"]))
    debit_html = gen_table_html(list_debit)
    return render_template("index2.html", user = user,debit_html = debit_html)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1357, debug=True)
