from email.policy import default
from flask_sqlalchemy import SQLAlchemy
from __init__ import app
import os

db = SQLAlchemy(app) 
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] =\
           'sqlite:///' + os.path.join(basedir, 'database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

def default_value(context):
    return context.get_current_parameters()['Material']
class Creator(db.Model):
    __tablename__ = "creator"
    id = db.Column(db.String(20), primary_key=True)
    phone = db.Column(db.String(20))
    name = db.Column(db.String(30))
    factory =db.Column(db.String(5))
    location = db.Column(db.String(50))
    email = db.Column(db.String(100))
    department =db.Column(db.String(20))
    price_no = db.Column(db.Numeric)
    debits = db.relationship('Debit')
    def __repr__(self):
        return f'<Creator "{self.name}">'

class Debit(db.Model):
    __tablename__ = "debit"
    id = db.Column(db.Integer, primary_key=True)
    sales_office = db.Column(db.Text)
    Sales_area = db.Column(db.Text)
    Order_Type = db.Column(db.Text)
    Plant_code = db.Column(db.Text)
    Sold_to_party = db.Column(db.Text)
    Ship_to_party = db.Column(db.Text)
    PO_No = db.Column(db.Text)
    PO_Date = db.Column(db.Date)
    Material = db.Column(db.Text)
    Material_No = db.Column(db.Text)
    Description = db.Column(db.Text, default= default_value)
    Order_Quantity = db.Column(db.Integer)
    Unit_price = db.Column(db.Numeric(10,5))
    Amount = db.Column(db.Numeric(10,2))
    Reference_no = db.Column(db.String(100))
    Assignment = db.Column(db.Text)
    Remark = db.Column(db.Text)
    creator_id = db.Column(db.String(20), db.ForeignKey('creator.id'), nullable=False)
    def __repr__(self):
        return f'<Debit "{self.id}...">'
if __name__ == "__main__":
    # db.drop_all()
    # db.create_all()
    pass