from unicodedata import name
from datetime import datetime
from urllib import request
from models import Creator, db, Debit
from sqlalchemy import (Column, Index, Date, DateTime, Numeric, BigInteger, String, ForeignKey, Boolean)

def add_debit_data(sales_office,Sales_area,Order_Type,Plant_code,Sold_to_party,Ship_to_party,PO_No,PO_Date,Material,Material_No,Description,Order_Quantity,Unit_price,Amount,Reference_no,Assignment,Remark,creator_id):
    new_debit = Debit(sales_office,Sales_area,Order_Type,Plant_code,Sold_to_party,Ship_to_party,PO_No,PO_Date,Material,Material_No,Description,Order_Quantity,Unit_price,Amount,Reference_no,Assignment,Remark,creator_id)
    db.session.add(new_debit)
    db.session.commit()
def get_user_info(customer_code):
    customer = Creator.query.filter_by(id=customer_code).first()
    return customer
# new_creator = Creator(id="12345",phone="phone",name = "phone",factory="phone",location="phone",email ="phone",department = "phone",price_no =123)
# new_debit = Debit(sales_office ="sdf",Sales_area="sadf",Order_Type="sadf",Plant_code="sadf",Sold_to_party="sadf",Ship_to_party="sadf",PO_No="sadf",PO_Date=datetime.strptime("19/2/2", '%y/%m/%d'),Material="sadf",Material_No="sadf",Description="sadf",Order_Quantity=123,Unit_price=12,Amount=12,Reference_no="sadf",Assignment="sadf",Remark="sadf",creator_id =3)
# db.session.add(new_debit)
# # db.session.add(new_creator)
# db.session.commit()
def get_list_debit(creator_id):
    return Debit.query.filter_by(creator_id = creator_id).all()

# find column type of class model
def find_type(class_, colname):
    if hasattr(class_, '__table__') and colname in class_.__table__.c:
        return class_.__table__.c[colname].type
    for base in class_.__bases__:
        return find_type(base, colname)
    raise NameError(colname)

def update_data(id,field_name, value):
    debit = Debit.query.filter_by(id = id).first()
    if str(getattr(debit,field_name)) == value:
        return "nothing"
    if field_name == "PO_Date":
        try:
            setattr(debit, field_name, datetime.strptime(value, '%Y-%m-%d'))
            db.session.commit()
            return "update ok"
        except: return "PO_Date must be match format year-month-day"
    else: 
        try:
            setattr(debit, field_name, value)
            if field_name == "Material" and getattr(debit,"Description")== None:
                setattr(debit, "Description", value)
            db.session.commit()
                
            return "update ok"
        except: 
            return "Value is invalid. Type of "+str(field_name) +" is "+str(find_type(Debit, field_name))
def return_empty_or_value(value):
    if value =="None": return ""
    return value
def gen_table_html(list_data):
    str_html = ""
    if(len(list_data)>0):    
        for data in list_data:
            str_html+='    <tr id ="'+str(data.id)+'">'
            
            str_html+='         <td class="first_col"><i class="bi bi-x-circle btn_delete" id = "delete-'+str(data.id)+'"></i></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-sales_office"+'"  value="'+return_empty_or_value(str(data.sales_office))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Sales_area"+'"  value="'+return_empty_or_value(str(data.Sales_area))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Order_Type"+'"  value="'+return_empty_or_value(str(data.Order_Type))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Plant_code"+'"  value="'+return_empty_or_value(str(data.Plant_code))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Sold_to_party"+'"  value="'+return_empty_or_value(str(data.Sold_to_party))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Ship_to_party"+'"  value="'+return_empty_or_value(str(data.Ship_to_party))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-PO_No"+'"  value="'+return_empty_or_value(str(data.PO_No))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-PO_Date"+'"  value="'+return_empty_or_value(str(data.PO_Date))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Material"+'"  value="'+return_empty_or_value(str(data.Material))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Material_No"+'"  value="'+return_empty_or_value(str(data.Material_No))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Description"+'"  value="'+return_empty_or_value(str(data.Description))+'"></td>'
            str_html+='         <td><input type="number" min="0" type="text" id="'+str(data.id)+"-Order_Quantity"+'"  value="'+return_empty_or_value(str(data.Order_Quantity))+'"></td>'
            str_html+='         <td><input type="number" id="'+str(data.id)+"-Unit_price"+'"  value="'+return_empty_or_value(str(data.Unit_price))+'"></td>'
            str_html+='         <td><input type="number" id="'+str(data.id)+"-Amount"+'"  value="'+return_empty_or_value(str(data.Amount))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Reference_no"+'"  value="'+return_empty_or_value(str(data.Reference_no))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Assignment"+'"  value="'+return_empty_or_value(str(data.Assignment))+'"></td>'
            str_html+='         <td><input type="text" id="'+str(data.id)+"-Remark"+'"  value="'+return_empty_or_value(str(data.Remark))+'"></td>'
            str_html+='</tr>'
    return str_html

def gen_table_html_not_input(list_data):
    str_html = ""
    if(len(list_data)>0):    
        for data in list_data:
            str_html+='    <tr>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.sales_office))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Sales_area))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Order_Type))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Plant_code))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Sold_to_party))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Ship_to_party))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.PO_No))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.PO_Date))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Material))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Material_No))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Description))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Order_Quantity))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Unit_price))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Amount))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Reference_no))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Assignment))+'</span></td>'
            str_html+='         <td> <span>'+return_empty_or_value(str(data.Remark))+'</span></td>'
            str_html+='</tr>'
    return str_html
def insert_empty_row(creator_id):
    new_debit = Debit(creator_id = creator_id)
    db.session.add(new_debit)
    db.session.commit()
    return str(new_debit.id)


def check_debit_empty(id_debit):
    pass

def delete_debit(id):
    try:
        Debit.query.filter(Debit.id == id).delete()
        db.session.commit()
        return True
    except: return False
# list_data = get_list("12345")
# if(len(list_data)>0):
#     for debit in list_data:
#         print(debit.sales_office)
# new_debit = Debit(creator_id = "12345")
# new_debit = Debit.query.filter_by(id = 3)

# db.session.add(new_debit)
# db.session.commit()
# update_data(3,"Unit_price",55555)
# debit = Debit.query.filter_by(id = 3).first()
# debit.sales_office = 12323
# db.session.commit()
# insert_empty_row("12345")
# insert_empty_row("12345")
# print(insert_empty_row("12345"))
